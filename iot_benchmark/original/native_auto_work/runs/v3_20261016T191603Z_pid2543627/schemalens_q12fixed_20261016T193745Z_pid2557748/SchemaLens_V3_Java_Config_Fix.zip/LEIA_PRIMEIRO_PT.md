# Correção do IoT Benchmark V3 — arquivos auxiliares de configuração

## Causa verificada no código Java oficial

No commit `62e0dc100e56443978c8b4c66472b1d8a7ef0238` de `thulab/iot-benchmark`, o método `Config.initInnerFunction()` abre `<benchmark-conf>/function.xml`. Se falhar, escreve um erro no logger e chama `System.exit(0)`. Na automação anterior criávamos só `config.properties` no diretório `java_config`. O logger também estava sem configuração, ocultando a causa. O encerramento com código zero fez o script concluir incorretamente que a execução Java tinha terminado normalmente.

O patch copia `function.xml`, `log4j.properties` e, se disponível, `logback.xml` da checkout oficial já fixada para cada `java_config` isolada. Além disso, fornece `-Dbenchmark-conf` e `-Dlog4j.configuration` aos dois processos Java — tanto a geração de CSV quanto a captura de consultas, garantindo que os dois usem a mesma configuração.

## Aplicação no Ubuntu

Na **raiz do projeto** `SchemaLens_IoT_Cassandra_V3_Automatico`, depois de colocar o ZIP:

```bash
unzip -o SchemaLens_V3_Java_Config_Fix.zip \
  scripts/auto_official_v3.py tests/test_java_config_fix.py

python3 -m unittest discover -s tests -p 'test_java_config_fix.py' -v

./run_v3_auto.sh --skip-java-build
```

A etapa 2 utiliza o core já compilado e as dependências do cache. **Não precisa de Cassandra**; não executa Stage 9; nem altera o HBench dos pilotos anteriores. Cada execução fica em novo subdiretório de `native_auto_work/runs`.

O resultado deve incluir `Copied official Java support files: function.xml, log4j.properties, logback.xml` e após Stage 3 a mensagem `Generated N native CSV files ...`. Se aparecer outro erro, copie as últimas linhas mostradas do `native_generation.log` — agora o Log4j estará configurado.

## Limitações

A correção foi conferida por testes offline. Aqui não foi possível compilar e executar o Java nativo usando Maven; essa validação depende de sua execução local. O script ainda captura amostras de objetos de parâmetros de consultas, não uma execução completa do escalonador SQL do IoT Benchmark.
