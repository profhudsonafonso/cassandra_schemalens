# Correção de diagnóstico do gerador IoT Benchmark V3

**Escopo:** corrige e melhora o script `scripts/auto_official_v3.py`, sem tocar nos Stages 1–9, famílias, pesos, HBench ou dados do piloto. Não executa benchmarks.

## O que estava ocorrendo

A execução chegou ao Java `generateDataMode`, mas terminou sem produzir `schema.txt` no `FILE_PATH` esperado. Sem o `native_generation.log` da máquina, não é possível atribuir a causa com certeza. A saída original escondia mensagens importantes do Java quando ele encerrava com código zero.

## Alterações

1. Define `-Dbenchmark-conf=<diretório>` na inicialização da JVM, além de manter `-cf <diretório>` no aplicativo. Isso protege o carregamento da configuração caso ocorra inicialização estática antecipada.
2. Exibe o diretório de configuração e o caminho esperado do dataset.
3. Se `schema.txt`, `info.txt` ou os arquivos `BigBatch_*.csv` estiverem ausentes, mostra automaticamente as últimas 100 linhas de `native_generation.log` e relata quais saídas faltaram.
4. Se o processo Java terminar com erro, mostra o fim do log antes de interromper.
5. Reduz a enorme listagem de dependências Java no terminal; a linha completa continua no log.

## Aplicação no Ubuntu (pasta do projeto original V3)

Baixe `SchemaLens_V3_Generation_Fix.zip`, coloque-o na pasta `SchemaLens_IoT_Cassandra_V3_Automatico` e execute:

```bash
unzip -o SchemaLens_V3_Generation_Fix.zip 'scripts/auto_official_v3.py' 'tests/test_generation_fix.py'
python3 -m unittest discover -s tests -p test_generation_fix.py -v
./run_v3_auto.sh --skip-java-build
```

O `--skip-java-build` é válido porque seu log já comprovou que Maven e a geração do classpath concluíram. O script reutilizará o clone e o build existentes, mas criará **outro diretório de execução**, sem substituir o anterior.

Se o script continuar parando na etapa `[3/7]`, copie as últimas linhas de log mostradas no terminal ou use:

```bash
find native_auto_work/runs -path '*/logs/native_generation.log' -type f -printf '%T@ %p\n' | sort -nr | head -3
```

Depois execute `tail -n 100 CAMINHO_DO_LOG` com o caminho mais recente.

**Importante:** o arquivo é uma correção defensiva e diagnóstica, não há comprovação de que o `-Dbenchmark-conf` sozinho resolva a falha específica do seu Ubuntu. O log irá confirmar ou descartar essa hipótese.
