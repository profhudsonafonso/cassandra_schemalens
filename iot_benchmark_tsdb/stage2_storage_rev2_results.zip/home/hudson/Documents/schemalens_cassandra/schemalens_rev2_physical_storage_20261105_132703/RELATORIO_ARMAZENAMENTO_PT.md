# SchemaLens Cassandra Rev2 — armazenamento físico (Stage 2)

Coleta somente de leitura feita após o benchmark confirmatório; não altera o HBench.

## Proveniência

- HBench SHA-256: `15eadb0f1e19bde6e721fa3829c9686c7a1ea063a33751597c9b31c0744c202d`
- Benchmark: `CONFIRMATORY_CASSANDRA_COMPLETE`
- Métricas SSTable disponíveis: **sim**.

## Tamanho por configuração

| Configuração | Tabelas | SSTable live bytes | SSTable total bytes | Memtable bytes | SSTables | Escritas físicas |
|---|---:|---:|---:|---:|---:|---:|
| `BASELINE_ORIGINAL` | 1 | 0 | 0 | 693048 | 0 | 9000 |
| `BASELINE_Q8_OPTIMIZED` | 1 | 0 | 0 | 693048 | 0 | 9000 |
| `R2H_6355f4e57096` | 1 | 0 | 0 | 954096 | 0 | 18000 |
| `R2H_bdc993acdde3` | 1 | 0 | 0 | 693528 | 0 | 9000 |
| `R2H_e72ef4d8529d` | 1 | 0 | 0 | 693048 | 0 | 9000 |

## Interpretação e limitações

- A baseline original e a baseline Q8 otimizada compartilham a mesma tabela: os tamanhos duplicados na apresentação não devem ser somados.
- `Space used (live)` é espaço de SSTables na instância consultada, e não bytes lógicos, transferência de rede ou tamanho total do banco.
- `Memtable data size` é memória estimada em buffers de escrita: não some indiscriminadamente às SSTables como se fosse um total físico uniforme.
- SSTables podem estar vazias se dados ainda estiverem no memtable. Esta coleta NÃO executa `nodetool flush` para preservar o estado observado.
- Se o SSTable count for zero, não conclua que o armazenamento é zero: faça uma etapa separada pós-benchmark com flush controlado, registrada em outro snapshot.
- Compaction e SSTables antigas podem afetar `Space used (total)`; comparar após flush e compaction naturais deve ser tratado como etapa própria.
- `Number of partitions (estimate)` é estimativa de cardinalidade, não tamanho máximo ou percentil das partições.
- Esses resultados não medem ingestão concorrente, manutenção de TS4, latência do servidor ou dimensões de partição individualizadas.
- Não reotimize a seleção congelada com essas medidas: uma mudança de custo exigiria nova revisão e novo holdout.

