# V3 — correção dos testes Rev2 para dados Java nativos (Stage8 já congelado)

## Diagnóstico do log

A1 importou **1.800 células métricas**; os Stages 4–8 concluíram e geraram **4 deployments congelados**, com **48 verificações semânticas offline** aprovadas. A validação final retornou erro exclusivamente nos dois testes `test_stage4_rev2.py`, que exigiam as constantes do fixture antigo (`18` linhas TS2 e colunas `m_s0`/`m_s1`). O IoT Benchmark Java utiliza sensores `s_0` e `s_1`, levando a colunas `m_s_0` e `m_s_1`, e gera **900 pares distintos dispositivo/timestamp** nesse conjunto.

## Correção

O patch modifica **somente o arquivo de testes**, sem alterar `iot_pipeline`, `phase_a1`, políticas, dados, consultas ou saídas dos Stages 4–8:

- DDL TS2: validar todas as colunas `m_{sensor_name}` derivadas dos dados importados.
- Materialização TS2: comparar a quantidade física com a cardinalidade de `(device_id, timestamp)` dos dados importados, independentemente do tamanho do dataset.
- Passar a lista de sensores efetiva ao simulador de materialização; verificar contagem TS0, template de INSERT e número de placeholders.

O comando de retomada copia o teste corrigido para **a mesma pasta isolada que já contém o HBench congelado**, mantendo cópia do teste anterior. Ele executa Stage9 apenas com `--dry-run` e os mesmos três conjuntos de testes offline. Não utiliza nem reinicializa Cassandra; não reexecuta Stages 1–8. Antes e depois, compara SHA-256 de todos os arquivos existentes nas pastas `outputs/stage4` até `outputs/stage8`. Salva o resultado em `outputs/validation_native_stage8/VALIDATION_RESULT.json`.

## Comandos exatos

Na pasta `SchemaLens_IoT_Cassandra_V3_Automatico` do Ubuntu:

```bash
unzip -o SchemaLens_V3_Native_Stage8_TestFix.zip

python3 scripts/validate_frozen_stage8_native.py --experiment \
  native_auto_work/runs/v3_20261016T191603Z_pid2543627/schemalens_q12fixed_20261016T193745Z_pid2557748
```

Se terminar com `SUCCESS`, você não precisa repetir download Git, compilação Maven, geração dos CSVs, captura Q1–Q12, A1 nem o congelamento do Stage8. O script mostra os caminhos do HBench e do manifesto congelado.

Envie `outputs/stage8/30_hbench_summary.csv`, `outputs/stage8/32_frozen_manifest.json` e `outputs/validation_native_stage8/VALIDATION_RESULT.json` da pasta isolada para análise.

## Limitação

Esse sucesso confirmará consistência dos contratos e rotas **offline** sob os objetos de parâmetros Java capturados. Não equivale a replay completo da sequência SQL oficial nem demonstra ganho de latência no Cassandra.
