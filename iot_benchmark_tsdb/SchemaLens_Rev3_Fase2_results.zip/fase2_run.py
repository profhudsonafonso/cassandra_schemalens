#!/usr/bin/env python3
"""Fase 2 orchestrator: runs preregistered steps in order, one process each, and stops at the
first failure. Completed steps (evidence file present) are skipped, so relaunching resumes.

    python fase2_run.py --stages e1         # E1 (r2 then r3)
    python fase2_run.py --stages e2 e3 e4 e5 e6
After every step the dashboard (experiments/rev3_fase2/dashboard.html) is regenerated.
"""
from __future__ import annotations

import argparse
import json
import os
import signal
import socket
import threading
import subprocess
import sys
import time
import datetime as dt
from pathlib import Path

PROJECT = Path(__file__).resolve().parent
F2 = PROJECT / 'experiments' / 'rev3_fase2'
STATUS = F2 / 'status.json'
LOGS = F2 / 'logs'
PY = sys.executable
CORE = [PY, '-u', 'fase2_core.py']
REV4 = [PY, '-u', 'fase2_rev4.py']
ANALYSIS = [PY, '-u', 'fase2_analysis.py']
MAT, FLU = '--confirm=CREATE_NEW_F2_KEYSPACES', '--confirm=FLUSH_F2_SST_ONLY'


def d(c, ds):
    return F2 / c / ds


def campaign_steps(c, datasets, materialize=True):
    s = []
    if materialize:
        for ds in datasets:
            s.append((f'{c}:mat:{ds}', f'Materializar {ds}', CORE + ['materialize', '--campaign', c, '--dataset', ds, MAT],
                      d(c, ds) / 'materialization' / 'materialization_manifest.json'))
        for ds in datasets:
            s.append((f'{c}:flush:{ds}', f'Flush + gate {ds}', CORE + ['flush', '--campaign', c, '--dataset', ds, FLU],
                      d(c, ds) / 'flush_manifest.json'))
        for ds in datasets:
            s.append((f'{c}:val:{ds}', f'Validação semântica {ds}', CORE + ['validate', '--campaign', c, '--dataset', ds],
                      d(c, ds) / 'semantic_validation.json'))
    return s


def run_steps(c, datasets):
    s = [(f'{c}:prereg', 'Pré-registro', CORE + ['preregister', '--campaign', c], F2 / c / 'preregistration.json')]
    for ds in datasets:
        s.append((f'{c}:run:{ds}', f'Medição {ds}', CORE + ['run', '--campaign', c, '--dataset', ds],
                  d(c, ds) / 'post_timing_manifest.json'))
        s.append((f'{c}:audit:{ds}', f'Auditoria {ds}', CORE + ['audit', '--campaign', c, '--dataset', ds],
                  d(c, ds) / 'benchmark' / 'audit.json'))
    return s


E1D = ['d1', 'd2', 'd4', 'd8']


def per_dataset_steps(c, datasets):
    """Amendment 01: load, gate, validate, preregister, time, audit and retire one factor at a time."""
    s = []
    for ds in datasets:
        s += campaign_steps(c, [ds])
        s.append((f'{c}:prereg:{ds}', f'Pré-registro {ds}', CORE + ['preregister', '--campaign', c, '--dataset', ds],
                  F2 / c / f'preregistration_{ds}.json'))
        s += run_steps(c, [ds])[1:]
        s.append((f'{c}:retire:{ds}', f'Aposentar memtables {ds}', CORE + ['retire', '--campaign', c, '--dataset', ds],
                  d(c, ds) / 'retire_manifest.json'))
    return s


STAGES = {
    'e1': [('E1', (f'e1r2:retire:{ds}', f'Aposentar e1r2 abortada {ds}', CORE + ['retire', '--campaign', 'e1r2', '--dataset', ds],
                   d('e1r2', ds) / 'retire_manifest.json')) for ds in E1D]
    + [('E1', st) for c in ('e1r2b', 'e1r3') for st in per_dataset_steps(c, E1D)]
    + [('E1', ('e1:analysis', 'Análise E1', ANALYSIS + ['e1'], F2 / 'analysis' / 'e1_summary.json'))],
    'e2': [('E2', ('e2:fit', 'Calibrar e congelar Rev4', REV4 + ['fit'], F2 / 'rev4' / 'rev4_frozen.json'))],
    'e3': [('E3', st) for st in campaign_steps('e3', ['h1', 'h2', 'h3'])]
    + [('E3', ('e3:predict', 'Previsões Rev4 (antes de medir)', REV4 + ['predict', 'e3'], F2 / 'rev4' / 'predictions_e3.json'))]
    + [('E3', st) for st in run_steps('e3', ['h1', 'h2', 'h3'])],
    'e4': [('E4', st) for st in campaign_steps('e4', ['n3', 'n18'])]
    + [('E4', ('e4:predict', 'Previsões Rev4 (antes de medir)', REV4 + ['predict', 'e4'], F2 / 'rev4' / 'predictions_e4.json'))]
    + [('E4', st) for st in run_steps('e4', ['n3', 'n18'])],
    'e5': [('E5', ('e5:analysis', 'Avaliar Rev4 + análise E3/E4', ANALYSIS + ['e345'], F2 / 'analysis' / 'e345_summary.json'))],
    'e6': [('E6', st) for st in run_steps('e6', ['h1', 'h3'])]
    + [('E6', ('e6:analysis', 'Análise cache frio', ANALYSIS + ['e6'], F2 / 'analysis' / 'e6_summary.json'))],
}


def now():
    return dt.datetime.now().astimezone().isoformat(timespec='seconds')


def load_status():
    try:
        return json.loads(STATUS.read_text())
    except Exception:
        return dict(steps={}, runs=[])


_SAVE_LOCK = threading.Lock()
HEARTBEAT_SECONDS = 60  # the dashboard flags the run as stale after ~2.5 heartbeats without a write


def save_status(st):
    with _SAVE_LOCK:
        if (st.get('current_run') or {}).get('state') == 'RUNNING':
            st['current_run']['heartbeat'] = now()
        tmp = STATUS.with_suffix('.tmp')
        tmp.write_text(json.dumps(st, indent=2, ensure_ascii=False))
        tmp.replace(STATUS)
        subprocess.run([PY, 'fase2_dashboard.py'], cwd=PROJECT, capture_output=True)


def start_heartbeat(st):
    """Rewrite status + dashboard every minute, so a silent step still shows the process is alive."""
    def beat():
        while True:
            time.sleep(HEARTBEAT_SECONDS)
            try:
                save_status(st)
            except RuntimeError:  # dict mutated by the main thread mid-dump; next beat will do
                pass
    threading.Thread(target=beat, daemon=True).start()


def _on_signal(signum, _frame):
    raise SystemExit(f'interrompido pelo sinal {signal.Signals(signum).name}')


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--stages', nargs='+', required=True, choices=list(STAGES))
    a = ap.parse_args()
    LOGS.mkdir(parents=True, exist_ok=True)
    st = load_status()
    plan = [(stage, *step) for s in a.stages for stage, step in STAGES[s]]
    st['current_run'] = dict(stages=a.stages, started=now(), state='RUNNING', error=None,
                             pid=os.getpid(), host=socket.gethostname())
    for sig in (signal.SIGTERM, signal.SIGHUP):
        signal.signal(sig, _on_signal)
    for stage, sid, title, cmd, done, in plan:
        st['steps'].setdefault(sid, dict(stage=stage, title=title, state='pending'))
    save_status(st)
    start_heartbeat(st)
    try:
        execute(st, plan)
    except (KeyboardInterrupt, SystemExit) as exc:
        if st['current_run'].get('state') == 'RUNNING':  # sys.exit(1) after a FAILED step is already recorded
            for rec in st['steps'].values():
                if rec['state'] == 'running':
                    rec.update(state='interrupted', ended=now())
            reason = str(exc) if isinstance(exc, SystemExit) and exc.code not in (None, 0, 1) else 'interrompido (Ctrl-C)'
            st['current_run'].update(state='STOPPED', error=reason, ended=now())
            save_status(st)
        raise
    st['current_run'].update(state='COMPLETE', ended=now(), current=None)
    save_status(st)
    print('COMPLETE', a.stages)


PARTIAL_RUN_OUTPUTS = ('benchmark', 'storage_pre_timing', 'storage_post_timing')


def quarantine_partial_run(st, sid, done):
    """Amendment 02: a measurement that ended without its post-timing manifest is discarded whole. Its partial
    outputs are moved (never deleted) to aborted_attempts/ and the measurement is repeated from the pre-timing gate."""
    folder = Path(done).parent
    found = [folder / n for n in PARTIAL_RUN_OUTPUTS if (folder / n).exists()]
    if not found:
        return
    k = len(list((folder / 'aborted_attempts').glob('*'))) + 1 if (folder / 'aborted_attempts').exists() else 1
    dest = folder / 'aborted_attempts' / f'{k:02d}_{dt.datetime.now().strftime("%Y%m%dT%H%M%S")}'
    dest.mkdir(parents=True)
    for f in found:
        f.rename(dest / f.name)
    files = sum(1 for _ in dest.rglob('*') if _.is_file())
    (dest / 'README.txt').write_text(f'Tentativa interrompida de {sid} (EMENDA_02). Saídas parciais preservadas, '
                                     f'não usadas em nenhuma análise. {files} arquivos movidos em {now()}.\n')
    st.setdefault('notes', []).append(f'{sid}: medição interrompida descartada; saídas parciais movidas para '
                                      f'{dest.relative_to(F2)} e medição refeita do zero (EMENDA_02).')
    print('QUARANTINED', sid, '->', dest, flush=True)


def execute(st, plan):
    for stage, sid, title, cmd, done in plan:
        rec = st['steps'][sid]
        if Path(done).exists():
            if rec['state'] != 'done':
                rec.update(state='done', note='evidência já existente')
            continue
        if ':run:' in sid:
            quarantine_partial_run(st, sid, done)
        if ':prereg' in sid:  # campaigns that reuse another campaign's keyspaces (E6) have no folder yet
            Path(done).parent.mkdir(parents=True, exist_ok=True)
        rec.update(state='running', started=now(), last='')
        st['current_run']['current'] = sid
        save_status(st)
        t0 = time.time()
        log = LOGS / (sid.replace(':', '_') + '.log')
        with log.open('a') as lf, subprocess.Popen(cmd, cwd=PROJECT, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                                   text=True) as p:
            last_save = 0
            for line in p.stdout:
                lf.write(line)
                lf.flush()
                rec['last'] = line.strip()[-200:]
                if time.time() - last_save > 30:
                    save_status(st)
                    last_save = time.time()
            rc = p.wait()
        rec['seconds'] = round(time.time() - t0, 1)
        rec['ended'] = now()
        if rc != 0 or not Path(done).exists():
            rec['state'] = 'failed'
            tail = log.read_text().splitlines()[-15:]
            st['current_run'].update(state='FAILED', error=f'{sid} rc={rc}\n' + '\n'.join(tail), ended=now())
            save_status(st)
            print('FAILED', sid, '\n'.join(tail))
            sys.exit(1)
        rec['state'] = 'done'
        save_status(st)
        print('DONE', sid, rec['seconds'], 's', flush=True)


if __name__ == '__main__':
    main()
