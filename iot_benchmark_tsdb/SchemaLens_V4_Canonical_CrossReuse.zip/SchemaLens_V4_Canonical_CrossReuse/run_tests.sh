#!/usr/bin/env bash
set -euo pipefail
if [[ $# -ne 1 ]]; then
  echo 'Usage: bash SchemaLens_V4_Canonical_CrossReuse/run_tests.sh path/to/isolated_V3_experiment' >&2
  exit 2
fi
ADDON="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
EXP="$(cd "$1" && pwd)"
export PYTHONPATH="$ADDON:$EXP${PYTHONPATH:+:$PYTHONPATH}"
python3 -m unittest discover -s "$ADDON/tests" -p 'test_v4.py' -v
