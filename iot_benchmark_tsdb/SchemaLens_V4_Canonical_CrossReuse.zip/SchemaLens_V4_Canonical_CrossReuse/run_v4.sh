#!/usr/bin/env bash
set -euo pipefail
if [[ $# -lt 4 ]]; then
  echo 'Usage: bash SchemaLens_V4_Canonical_CrossReuse/run_v4.sh --experiment PATH --mode offline|live [options]' >&2
  exit 2
fi
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
EXP=''
argv=("$@")
for ((i=0;i<${#argv[@]};i++)); do
  if [[ "${argv[$i]}" == '--experiment' ]]; then
    if ((i+1 >= ${#argv[@]})); then echo 'Missing --experiment path' >&2; exit 2; fi
    EXP="${argv[$((i+1))]}"
  elif [[ "${argv[$i]}" == --experiment=* ]]; then
    EXP="${argv[$i]#--experiment=}"
  fi
done
if [[ -z "$EXP" ]]; then echo 'Explicit --experiment required' >&2; exit 2; fi
if [[ ! -f "$EXP/outputs/stage8/28_hbench_frozen.json" ]]; then
  echo "V3 isolated frozen experiment not found: $EXP" >&2; exit 2
fi
EXP_ABS="$(cd "$EXP" && pwd)"
# IMPORTANT: the native_reference_v3 add-on exists in the ISOLATED experiment,
# not necessarily in the outer V3 project. Do not import the wrong iot_pipeline.
export PYTHONPATH="$SCRIPT_DIR:$EXP_ABS${PYTHONPATH:+:$PYTHONPATH}"
python3 -m diagnostic_v4.cli "$@"
